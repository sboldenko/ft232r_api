FT601Tool
FTDI FT601 send/receive tool

This program runs on an ARM64 system with an FT601 chip connected via USB.


How to build from source
------------------------
Use the makefile:
	make


How to use
----------
Show the driver and library version and device details:
	ft601tool -V

Send raw data from a file to a FIFO channel:
	ft601tool -S FILE -c CH
Example:
	ft601tool -S data.bin -c 0

Receive raw data from a FIFO channel and write it to a file:
	ft601tool -R FILE -l LENGTH -c CH
Example:
	ft601tool -R data.bin -l 100 -c 0

Send a data packet from a file to an address to a FIFO channel:
	ft601tool -s FILE -c CH -a ADDR
Example:
	ft601tool -s data.bin -c 0 -a 1234

Request and receive a data packet from a FIFO channel at an address and write it to a file:
	ft601tool -r FILE -l LENGTH -c CH -a ADDR
Example:
	ft601tool -r data.bin -l 100 -c 0 -a 1234

All command line options:
	ft601tool -h
