#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <getopt.h>
#include "ftd3xx.h"

using namespace std;


// ==================== Command line options ====================

#define GETOPTS_ARGS "hVS:R:s:r:l:c:ba:"

static struct option long_options[] =
{
	{"help",        no_argument,       0, 'h'},
	{"version",     no_argument,       0, 'V'},
	{"send",        required_argument, 0, 's'},
	{"receive",     required_argument, 0, 'r'},
	{"send-raw",    required_argument, 0, 'S'},
	{"receive-raw", required_argument, 0, 'R'},
	{"length",      required_argument, 0, 'l'},
	{"channel",     required_argument, 0, 'c'},
	{"burst",       no_argument,       0, 'b'},
	{"address",     required_argument, 0, 'a'},
	{0, 0, 0, 0}
};

static void help_options()
{
	fprintf(stderr, "FTDI FT601 send/receive tool.\n");
	fprintf(stderr, "Usage:\n");
	fprintf(stderr, "  -V, --version           Print version information and device details.\n");
	fprintf(stderr, "  -s, --send FILE         Send a packet with the contents of the FILE.\n");
	fprintf(stderr, "  -r, --receive FILE      Receive a packet and write it to the FILE.\n");
	fprintf(stderr, "  -S, --send-raw FILE     Send the raw contents of the FILE.\n");
	fprintf(stderr, "  -R, --receive-raw FILE  Receive raw data and write it to the FILE.\n");
	fprintf(stderr, "  -l, --length LEN        Receive LEN bytes (required with -r and -R).\n");
	fprintf(stderr, "  -c, --channel CH        Use FIFO channel CH (0 to 3, default: 0).\n");
	fprintf(stderr, "  -b, --burst             Set the burst bit in the request packet header.\n");
	fprintf(stderr, "  -a, --address ADDR      Set the address in the request packet header.\n");
}


// ==================== Helper functions ====================

bool checkStatus(FT_STATUS status, const char* message)
{
	if (status != FT_OK)
	{
		printf("Error %d: %s\n", status, message);
		return false;
	}
	return true;
}


// ==================== Main program ====================

int main(int argc, char* argv[])
{
	int c;
	bool help = false;
	bool version = false;
	char* sendFile = nullptr;
	char* receiveFile = nullptr;
	bool packetFormat = false;
	bool burst = false;
	uint32_t length = 0;
	uint32_t address = 0;
	int channel = 0;

	int option_index = 0;
	while ((c = getopt_long(argc, argv, GETOPTS_ARGS, long_options, &option_index)) != -1)
	{
		switch (c)
		{
			case 'h':
				help = true;
				break;
			case 'V':
				version = true;
				break;
			case 's':
				sendFile = strdup(optarg);
				packetFormat = true;
				break;
			case 'r':
				receiveFile = strdup(optarg);
				packetFormat = true;
				break;
			case 'S':
				sendFile = strdup(optarg);
				break;
			case 'R':
				receiveFile = strdup(optarg);
				break;
			case 'l':
				length = strtoul(optarg, NULL, 0);
				break;
			case 'c':
				channel = strtoul(optarg, NULL, 0);
				break;
			case 'b':
				burst = true;
				break;
			case 'a':
				address = strtoul(optarg, NULL, 0);
				break;
			default:
				return -1;
		}
	}

	if (help)
	{
		help_options();
		return -1;
	}

	if (version)
	{
		DWORD dwVersion;
		FT_GetDriverVersion(NULL, &dwVersion);
		printf("Driver version: %d.%d.%d\n", dwVersion >> 24, (uint8_t)(dwVersion >> 16), dwVersion & 0xFFFF);
		FT_GetLibraryVersion(&dwVersion);
		printf("Library version: %d.%d.%d\n", dwVersion >> 24, (uint8_t)(dwVersion >> 16), dwVersion & 0xFFFF);

		DWORD count;
		if (!checkStatus(FT_CreateDeviceInfoList(&count), "FT_CreateDeviceInfoList"))
			return 1;
		printf("Found %u FT60x USB devices\n", count);
		FT_DEVICE_LIST_INFO_NODE nodes[16];
		if (count > 16)
			count = 16;   // Limit request to reserved memory
		if (!checkStatus(FT_GetDeviceInfoList(nodes, &count), "FT_GetDeviceInfoList"))
			return 1;

		for (DWORD i = 0; i < count; i++)
		{
			DWORD flags, type, id, locId;
			char serialNumber[16], description[32];
			FT_HANDLE handle;
			if (!checkStatus(FT_GetDeviceInfoDetail(i, &flags, &type, &id, &locId, serialNumber, description, &handle), "FT_GetDeviceInfoDetail"))
				return 1;
			const char* flagsDescription = flags & FT_FLAGS_SUPERSPEED ? "[USB 3]" :
				flags & FT_FLAGS_HISPEED ? "[USB 2]" :
				flags & FT_FLAGS_OPENED ? "[OPENED]" : "";
			printf("Device %d: flags=0x%x %s type=%u id=%u locId=%u serialNum=%s desc=%s\n", i, flags, flagsDescription, type, id, locId, serialNumber, description);
		}
		return 0;
	}

	if (sendFile)
	{
		FT_HANDLE handle;
		if (!checkStatus(FT_Create(0, FT_OPEN_BY_INDEX, &handle), "FT_Create"))
			return 1;
		printf("Device 0 opened\n");

		FILE* file = fopen(sendFile, "rb");
		if (!file)
		{
			printf("File cannot be opened.\n");
			return 1;
		}
		fseek(file, 0, SEEK_END);
		long filelen = ftell(file);
		rewind(file);

		ULONG bytesSent, totalBytesSent = 0;
		if (packetFormat)
		{
			if (filelen > 1023)
			{
				printf("File size exceeds limit of packet format (max. 1023 bytes).\n");
				return 1;
			}
			if (filelen % 4)
			{
				printf("File size is not aligned to 4 bytes.\n");
				return 1;
			}

			long headerlen = 12;
			long footerlen = 4;
			long datalen = headerlen + filelen + footerlen;
			UCHAR* data = (PUCHAR)malloc(datalen * sizeof(UCHAR));
			data[0] = 0xaf;   // Little-endian byte order as requested
			data[1] = 0xbe;
			data[2] = 0xbe;
			data[3] = 0xba;
			data[4] = filelen / 4;   // Data length divided by 4 (truncated)
			data[5] = burst ? 0x80 : 0x00;
			data[6] = 0x1;   // Type
			data[7] = 0;   // Unique packet number
			data[8] = address & 0xff;   // Little-endian byte order as requested
			data[9] = (address >> 8) & 0xff;
			data[10] = (address >> 16) & 0xff;
			data[11] = (address >> 24) & 0xff;

			long readlen = fread(data + headerlen, 1, filelen, file);
			fclose(file);
			if (readlen != filelen)
			{
				printf("File could not be read completely.\n");
				return 1;
			}
			// Reinterpret data as 32-bit integers, reverse byte order as requested
			for (int i = 0; i < filelen; i += 4)
			{
				long b0 = data[headerlen + i + 0];
				long b1 = data[headerlen + i + 1];
				long b2 = data[headerlen + i + 2];
				long b3 = data[headerlen + i + 3];
				data[headerlen + i + 0] = b3;
				data[headerlen + i + 1] = b2;
				data[headerlen + i + 2] = b1;
				data[headerlen + i + 3] = b0;
			}

			long footerStart = headerlen + filelen;
			data[footerStart + 0] = 0xe0;
			data[footerStart + 1] = 0xe0;
			data[footerStart + 2] = 0xe0;
			data[footerStart + 3] = 0xe0;

			if (!checkStatus(FT_WritePipeEx(handle, channel, data, datalen, &bytesSent, 0xFFFFFFFF), "FT_WritePipeEx"))
				return 1;
			free(data);
			totalBytesSent += bytesSent;
		}
		else
		{
			UCHAR* buffer = (PUCHAR)malloc(filelen * sizeof(UCHAR));
			filelen = fread(buffer, 1, filelen, file);
			fclose(file);

			if (!checkStatus(FT_WritePipeEx(handle, channel, buffer, filelen, &bytesSent, 0xFFFFFFFF), "FT_WritePipeEx (data)"))
				return 1;
			free(buffer);
			totalBytesSent += bytesSent;
		}

		FT_Close(handle);
		printf("Sent %d bytes to channel %d\n", totalBytesSent, channel);
		return 0;
	}

	if (receiveFile)
	{
		FT_HANDLE handle;
		if (!checkStatus(FT_Create(0, FT_OPEN_BY_INDEX, &handle), "FT_Create"))
			return 1;
		printf("Device 0 opened\n");

		ULONG bytesSent, totalBytesSent = 0;
		if (packetFormat)
		{
			long headerlen = 12;
			UCHAR* header = (PUCHAR)malloc(headerlen * sizeof(UCHAR));
			header[0] = 0xba;
			header[1] = 0xbe;
			header[2] = 0xbe;
			header[3] = 0xaf;
			header[4] = length / 4;   // Data length divided by 4 (truncated)
			header[5] = burst ? 0x80 : 0x00;
			header[6] = 0x2;   // Type
			header[7] = 0;   // Unique packet number
			header[8] = (address >> 24) & 0xff;
			header[9] = (address >> 16) & 0xff;
			header[10] = (address >> 8) & 0xff;
			header[11] = address & 0xff;
			if (!checkStatus(FT_WritePipeEx(handle, channel, header, headerlen, &bytesSent, 0xFFFFFFFF), "FT_WritePipeEx (header)"))
				return 1;
			free(header);
			totalBytesSent += bytesSent;

			long footerlen = 4;
			UCHAR* footer = (PUCHAR)malloc(footerlen * sizeof(UCHAR));
			footer[0] = 0xe0;
			footer[1] = 0xe0;
			footer[2] = 0xe0;
			footer[3] = 0xe0;
			if (!checkStatus(FT_WritePipeEx(handle, channel, footer, footerlen, &bytesSent, 0xFFFFFFFF), "FT_WritePipeEx (footer)"))
				return 1;
			free(footer);
			totalBytesSent += bytesSent;
			printf("Sent %d bytes (request) to channel %d\n", totalBytesSent, channel);

			length += headerlen + footerlen;
		}

		ULONG bytesReceived;
		UCHAR* buffer = (PUCHAR)malloc(length * sizeof(UCHAR));
		if (!checkStatus(FT_ReadPipeEx(handle, channel, buffer, length, &bytesReceived, 0xFFFFFFFF), "FT_ReadPipeEx"))
			return 1;
		FT_Close(handle);
		printf("Received %d bytes from channel %d\n", bytesReceived, channel);

		FILE* file = fopen(receiveFile, "wb");
		if (!file)
		{
			printf("File cannot be opened.\n");
			return 1;
		}

		fwrite(buffer, 1, bytesReceived, file);
		fclose(file);
		free(buffer);
		printf("Data written to file\n");
		return 0;
	}

	printf("No command specified, show help with --help.\n");
	return -1;
}
